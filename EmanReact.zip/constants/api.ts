// constants/api.ts

// Jab bhi aapka Wi-Fi IP badle, sirf yahan ek baar change karein!
const IP_ADDRESS = "emen.trivexait.online";
// const IP_ADDRESS = "192.168.0.106";
const PORT = "";

export const API_URL = `http://${IP_ADDRESS}/api`;
