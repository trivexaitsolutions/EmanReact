// app/_layout.tsx
import * as Notifications from "expo-notifications";
import { Stack, router } from "expo-router";
import { useEffect } from "react";

// 1. Notification ka behaviour set karo
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true, // App ON hone par bhi banner dikhao
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export default function RootLayout() {
  useEffect(() => {
    const handleNotificationData = (data: any) => {
      console.log("Notification Data:", data);

      if (!data?.action) return;

      // Worker ko new duty mili
      if (data.action === "OPEN_ACTIVE_DUTY") {
        setTimeout(() => {
          router.push("/worker/active-duty");
        }, 500);
        return;
      }

      // Duty complete hui
      if (data.action === "DUTY_COMPLETED") {
        setTimeout(() => {
          router.replace("/worker/dashboard");
        }, 500);
        return;
      }

      // Client ne specific worker ki duty cancel ki
      if (data.action === "WORKER_CANCELLED_BY_CLIENT") {
        setTimeout(() => {
          router.push({
            pathname: "/worker/cancelled-duty",
            params: {
              type: "WORKER_CANCELLED_BY_CLIENT",
              reason: String(data.reason || ""),
              amount: String(data.amount || 0),
              bookingId: String(data.bookingId || ""),
              workerId: String(data.workerId || ""),
            },
          });
        }, 500);
        return;
      }

      // Client ne poori booking cancel ki
      if (data.action === "BOOKING_CANCELLED_BY_CLIENT") {
        setTimeout(() => {
          router.push({
            pathname: "/worker/cancelled-duty",
            params: {
              type: "BOOKING_CANCELLED_BY_CLIENT",
              reason: String(data.reason || ""),
              amount: String(data.amount || 0),
              bookingId: String(data.bookingId || ""),
              workerId: String(data.workerId || ""),
            },
          });
        }, 500);
      }
    };

    // 2. App background/locked tha, user ne notification par tap kiya
    const responseListener =
      Notifications.addNotificationResponseReceivedListener((response) => {
        const data = response.notification.request.content.data;

        console.log("Worker tapped notification:", data);

        handleNotificationData(data);
      });

    // 3. App foreground me hai aur notification receive hui
    const notificationListener = Notifications.addNotificationReceivedListener(
      (notification) => {
        const data = notification.request.content.data;

        console.log("Worker received notification:", data);

        handleNotificationData(data);
      },
    );

    // Cleanup
    return () => {
      responseListener.remove();
      notificationListener.remove();
    };
  }, []);

  return (
    <Stack>
      <Stack.Screen name="index" options={{ headerShown: false }} />

      <Stack.Screen name="auth/login" options={{ headerShown: false }} />

      <Stack.Screen name="worker/dashboard" options={{ headerShown: false }} />

      <Stack.Screen
        name="worker/active-duty"
        options={{ headerShown: false, animation: "slide_from_bottom" }}
      />

      <Stack.Screen
        name="worker/cancelled-duty"
        options={{ headerShown: false, animation: "slide_from_bottom" }}
      />
    </Stack>
  );
}
