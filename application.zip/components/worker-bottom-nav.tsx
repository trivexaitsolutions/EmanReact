import { router, usePathname } from "expo-router";
import {
  BriefcaseBusiness,
  CircleUserRound,
  House,
  Wallet,
} from "lucide-react-native";
import React from "react";
import { StyleSheet, Text, TouchableOpacity, View } from "react-native";

type WorkerTab = "home" | "jobs" | "wallet" | "profile";

const tabs: Array<{
  key: WorkerTab;
  label: string;
  route:
    | "/worker/dashboard"
    | "/worker/history"
    | "/worker/wallet"
    | "/worker/profile";
  icon: typeof House;
}> = [
  { key: "home", label: "Home", route: "/worker/dashboard", icon: House },
  { key: "jobs", label: "Jobs", route: "/worker/history", icon: BriefcaseBusiness },
  { key: "wallet", label: "Wallet", route: "/worker/wallet", icon: Wallet },
  { key: "profile", label: "Profile", route: "/worker/profile", icon: CircleUserRound },
];

const getActiveTab = (pathname: string): WorkerTab | null => {
  if (pathname === "/worker/dashboard" || pathname === "/worker/available") return "home";
  if (
    pathname === "/worker/history" ||
    pathname === "/worker/booking-details" ||
    pathname === "/worker/active-duty" ||
    pathname === "/worker/duty-in-progress" ||
    pathname === "/worker/cancelled-duty" ||
    pathname === "/worker/rate-client"
  ) return "jobs";
  if (pathname === "/worker/wallet") return "wallet";
  if (pathname === "/worker/profile") return "profile";
  return null;
};

export default function WorkerBottomNav() {
  const pathname = usePathname();
  const active = getActiveTab(pathname);

  return (
    <View style={styles.container}>
      {tabs.map((tab) => {
        const isActive = tab.key === active;
        const Icon = tab.icon;

        return (
          <TouchableOpacity
            key={tab.key}
            activeOpacity={0.78}
            style={styles.item}
            onPress={() => {
              if (!isActive) router.replace(tab.route);
            }}
          >
            <Icon color={isActive ? "#087C49" : "#6B7280"} size={23} />
            <Text style={[styles.label, isActive && styles.labelActive]}>{tab.label}</Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    minHeight: 68,
    backgroundColor: "#FFFFFF",
    borderTopColor: "#E5E7EB",
    borderTopWidth: 1,
    flexDirection: "row",
    paddingBottom: 10,
    paddingTop: 8,
  },
  item: {
    alignItems: "center",
    flex: 1,
    justifyContent: "center",
  },
  label: {
    color: "#6B7280",
    fontSize: 11,
    fontWeight: "700",
    marginTop: 4,
  },
  labelActive: {
    color: "#087C49",
  },
});
