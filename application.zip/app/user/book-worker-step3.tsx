import AsyncStorage from "@react-native-async-storage/async-storage";
import axios from "axios";
import { router, Stack, useFocusEffect } from "expo-router";
import { Check, MapPin, X } from "lucide-react-native";
import React, { useCallback, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Modal,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import RazorpayCheckout from "react-native-razorpay";
import BookingStepHeader from "../../components/booking-step-header";
import { API_URL } from "../../constants/api";

const RAZORPAY_KEY_ID = "rzp_test_SouUYINcIpP7iB";

type BookingDraft = {
  skillId?: number;
  skillName?: string;
  minRating?: number;
  workerCount?: number;
  selectedNakas?: any[];
  nakaIds?: number[];
  addressId?: number;
  assignmentMode?: "AUTO" | "CUSTOMER_SELECT";
  selectedWorkerIds?: number[];
  selectedWorkers?: {
    id: number;
    name?: string;
    averageRating?: number;
  }[];
  workLatitude?: number;
  workLongitude?: number;
  workAddress?: string;
  serviceRadiusKm?: number;
  serviceRadiusMeters?: number;
};

export default function BookWorkerStep3() {
  const [isLoading, setIsLoading] = useState(true);

  const [isPaying, setIsPaying] = useState(false);

  const [customer, setCustomer] = useState<any>(null);

  const [draft, setDraft] = useState<BookingDraft>({});

  const [addresses, setAddresses] = useState<any[]>([]);

  const [selectedAddress, setSelectedAddress] = useState<any>(null);

  const [showAddressModal, setShowAddressModal] = useState(false);

  const [unitPrice, setUnitPrice] = useState(0);

  useFocusEffect(
    useCallback(() => {
      loadPageData();
      // Page data intentionally refreshes whenever this route receives focus.
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []),
  );

  const loadPageData = async () => {
    try {
      setIsLoading(true);

      const session = await AsyncStorage.getItem("customerSession");

      const savedDraft = await AsyncStorage.getItem("newBookingDraft");

      if (!session) {
        Alert.alert("Session Error", "Please login again.");

        router.replace("/");
        return;
      }

      if (!savedDraft) {
        Alert.alert(
          "Booking Details Missing",
          "Please start your booking again.",
        );

        router.replace("/user/book-worker-step1");

        return;
      }

      const parsedCustomer = JSON.parse(session);

      const parsedDraft = JSON.parse(savedDraft);

      setCustomer(parsedCustomer);
      setDraft(parsedDraft);

      const [addressResponse, optionResponse] = await Promise.all([
        axios.get(`${API_URL}/user/customer-addresses/${parsedCustomer.id}`),

        axios.get(`${API_URL}/user/booking-options`),
      ]);

      if (addressResponse.data.success) {
        const addressList = addressResponse.data.addresses || [];

        setAddresses(addressList);

        const draftAddress = addressList.find(
          (item: any) => Number(item.id) === Number(parsedDraft.addressId),
        );

        const defaultAddress = addressList.find((item: any) => item.isDefault);

        const initialAddress =
          draftAddress || defaultAddress || addressList[0] || null;

        setSelectedAddress(initialAddress);

        if (initialAddress) {
          const updatedDraft = {
            ...parsedDraft,
            addressId: Number(initialAddress.id),
          };

          setDraft(updatedDraft);

          await AsyncStorage.setItem(
            "newBookingDraft",
            JSON.stringify(updatedDraft),
          );
        }
      }

      if (optionResponse.data.success) {
        calculateRate(optionResponse.data.skills || [], parsedDraft);
      }
    } catch (error: any) {
      console.log("Step 3 load error:", error?.response?.data || error);

      Alert.alert("Error", "Booking details load nahi ho payi.");
    } finally {
      setIsLoading(false);
    }
  };

  const calculateRate = (skills: any[], bookingDraft: BookingDraft) => {
    const currentSkill = skills.find(
      (skill: any) => Number(skill.id) === Number(bookingDraft.skillId),
    );

    if (!currentSkill) {
      setUnitPrice(0);
      return;
    }

    const rates = Array.isArray(currentSkill.rates) ? currentSkill.rates : [];

    if (rates.length === 0) {
      setUnitPrice(0);
      return;
    }

    const selectedRating = Number(bookingDraft.minRating || 0);

    if (selectedRating > 0) {
      const exactRate = rates.find(
        (rate: any) => Number(rate.star) === selectedRating,
      );

      if (exactRate) {
        setUnitPrice(Number(exactRate.rate || 0));

        return;
      }
    }

    const sortedRates = [...rates].sort(
      (a: any, b: any) => Number(a.rate) - Number(b.rate),
    );

    setUnitPrice(Number(sortedRates[0]?.rate || 0));
  };

  const handleSelectAddress = async (address: any) => {
    setSelectedAddress(address);
    setShowAddressModal(false);

    try {
      const savedDraft = await AsyncStorage.getItem("newBookingDraft");

      const oldDraft = savedDraft ? JSON.parse(savedDraft) : {};

      const updatedDraft = {
        ...oldDraft,
        addressId: Number(address.id),
      };

      await AsyncStorage.setItem(
        "newBookingDraft",
        JSON.stringify(updatedDraft),
      );

      setDraft(updatedDraft);
    } catch (error) {
      console.log("Address draft save error:", error);
    }
  };

  const cancelPendingBookingSafely = async (
    bookingId: number,
    customerId: number,
  ) => {
    try {
      await axios.post(`${API_URL}/user/cancel-pending-booking`, {
        bookingId,
        customerId,
      });
    } catch (error: any) {
      console.log(
        "Pending booking cancellation error:",
        error?.response?.data || error,
      );
    }
  };

  const handleProceedToPayment = async () => {
    if (isPaying) {
      return;
    }

    if (!customer?.id) {
      Alert.alert(
        "Session Error",
        "Customer session not found. Please login again.",
      );

      return;
    }

    if (!selectedAddress?.id) {
      Alert.alert("Select Address", "Please select your work address.");

      return;
    }

    if (!draft.skillId) {
      Alert.alert("Skill Missing", "Please select a worker skill.");

      return;
    }

    if (
      !Number.isFinite(Number(draft.workLatitude)) ||
      !Number.isFinite(Number(draft.workLongitude))
    ) {
      Alert.alert(
        "Work Location Missing",
        "Please confirm the exact work location on map.",
        [
          {
            text: "Confirm Location",
            onPress: () => router.push("/user/book-worker-step2"),
          },
        ],
      );

      return;
    }

    if (draft.assignmentMode === "CUSTOMER_SELECT") {
      const selectedWorkerIds = Array.isArray(draft.selectedWorkerIds)
        ? draft.selectedWorkerIds
            .map((id) => Number(id))
            .filter((id) => Number.isInteger(id) && id > 0)
        : [];

      if (selectedWorkerIds.length !== Number(draft.workerCount || 1)) {
        Alert.alert(
          "Select Workers",
          "Please select the required number of workers before payment.",
          [
            {
              text: "Select Workers",
              onPress: () =>
                router.push("/user/book-worker-select-workers"),
            },
          ],
        );

        return;
      }
    }

    let createdBookingId: number | null = null;

    let paymentCompleted = false;

    try {
      setIsPaying(true);

      /*
       * Step 1:
       * Backend booking create karega,
       * workers lock karega aur Razorpay
       * order return karega.
       */
      const initiateResponse = await axios.post(
        `${API_URL}/user/initiate-booking`,
        {
          customerId: Number(customer.id),

          skillId: Number(draft.skillId),

          workerCount: Number(draft.workerCount || 1),

          minRating: Number(draft.minRating || 0),

          addressId: Number(selectedAddress.id),

          workLatitude: Number(draft.workLatitude),

          workLongitude: Number(draft.workLongitude),

          workLocationText: draft.workAddress || "",

          selectedWorkerIds:
            draft.assignmentMode === "CUSTOMER_SELECT"
              ? (draft.selectedWorkerIds || []).map((id) => Number(id))
              : [],
        },
      );

      if (!initiateResponse.data.success) {
        throw new Error(
          initiateResponse.data.message || "Booking initiate nahi ho payi.",
        );
      }

      createdBookingId = Number(initiateResponse.data.bookingId);

      const razorpayOrder = initiateResponse.data.razorpayOrder;

      if (!createdBookingId || !razorpayOrder?.id || !razorpayOrder?.amount) {
        throw new Error("Invalid payment order received.");
      }

      /*
       * Step 2:
       * Razorpay popup open karo.
       */
      const paymentData: any = await RazorpayCheckout.open({
        key: RAZORPAY_KEY_ID,

        order_id: razorpayOrder.id,

        amount: razorpayOrder.amount,

        currency: razorpayOrder.currency || "INR",

        name: "E-MAN",

        description: `${draft.skillName || "Worker"} booking`,

        theme: {
          color: "#16863A",
        },

        prefill: {
          name: customer.name || "",

          email: customer.email || "",

          contact: customer.phone || "",
        },

        notes: {
          bookingId: String(createdBookingId),

          selectedNakas: (draft.nakaIds || []).join(","),
        },
      });

      /*
       * Razorpay result mil gaya,
       * iska matlab payment attempt successful
       * side tak pahunch gaya.
       */
      paymentCompleted = true;

      /*
       * Step 3:
       * Backend signature verification.
       */
      const verifyResponse = await axios.post(
        `${API_URL}/user/verify-payment`,
        {
          razorpay_payment_id: paymentData.razorpay_payment_id,

          razorpay_order_id: paymentData.razorpay_order_id,

          razorpay_signature: paymentData.razorpay_signature,

          bookingId: createdBookingId,
        },
      );

      if (!verifyResponse.data.success) {
        throw new Error(
          verifyResponse.data.message || "Payment verification failed.",
        );
      }

      /*
       * Booking complete hone ke baad
       * old draft remove karo.
       */
      await AsyncStorage.removeItem("newBookingDraft");

      router.replace("/user/active-booking");
    } catch (error: any) {
      console.log(
        "Booking payment error:",
        error?.response?.data || error?.description || error,
      );

      /*
       * Payment se pehle popup cancel/fail hua,
       * to pending booking delete karke
       * workers release karo.
       */
      if (createdBookingId && !paymentCompleted) {
        await cancelPendingBookingSafely(createdBookingId, Number(customer.id));
      }

      /*
       * Payment ho chuka ho lekin verification
       * fail hui ho to booking delete nahi karni.
       */
      if (paymentCompleted) {
        Alert.alert(
          "Payment Verification Pending",
          "Payment complete hua hai, lekin verification me dikkat aayi. Dobara payment mat karein. Please admin se contact karein.",
        );

        return;
      }

      const errorCode = error?.response?.data?.code;

      if (
        errorCode === "WORKERS_NO_LONGER_AVAILABLE" ||
        errorCode === "SELECTED_WORKERS_INVALID"
      ) {
        Alert.alert(
          "Worker No Longer Available",
          error?.response?.data?.message ||
            "Selected worker ab available nahi hai. Please worker dobara select karein.",
          [
            {
              text: "Select Worker",
              onPress: () =>
                router.replace("/user/book-worker-select-workers"),
            },
          ],
        );

        return;
      }

      if (errorCode === "NO_NAKAS_IN_RADIUS") {
        Alert.alert(
          "Service Area Changed",
          error?.response?.data?.message ||
            "Is work location ke nearby verified Naka nahi mila.",
          [
            {
              text: "Change Location",
              onPress: () => router.replace("/user/book-worker-step2"),
            },
          ],
        );

        return;
      }

      const errorMessage =
        error?.response?.data?.message ||
        error?.description ||
        error?.message ||
        "Payment complete nahi ho paya.";

      Alert.alert("Payment Cancelled", errorMessage);
    } finally {
      setIsPaying(false);
    }
  };

  const workerCount = Number(draft.workerCount || 1);

  const totalAmount = unitPrice * workerCount;

  const ratingText =
    Number(draft.minRating || 0) === 0
      ? "Any rating"
      : `${draft.minRating}★ & above`;

  const selectedNakaCount = Array.isArray(draft.selectedNakas)
    ? draft.selectedNakas.length
    : 0;

  const selectedWorkerNames = Array.isArray(draft.selectedWorkers)
    ? draft.selectedWorkers
        .map((worker: any) => worker.name)
        .filter(Boolean)
        .join(", ")
    : "";

  const visibleAddresses = addresses.slice(0, 4);

  if (isLoading) {
    return (
      <SafeAreaView style={styles.loaderContainer}>
        <Stack.Screen options={{ headerShown: false }} />

        <ActivityIndicator size="large" color="#16863A" />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen options={{ headerShown: false }} />
      <BookingStepHeader step={3} />

      <View style={styles.content}>
        {selectedAddress ? (
          <View style={styles.addressCard}>
            <View style={styles.cardTopRow}>
              <View style={styles.addressTitleRow}>
                <MapPin size={18} color="#16863A" />
                <Text style={styles.cardTitle}>{selectedAddress.title || "Work Address"}</Text>
              </View>
              {addresses.length > 1 ? (
                <TouchableOpacity disabled={isPaying} onPress={() => setShowAddressModal(true)}>
                  <Text style={styles.changeText}>Change</Text>
                </TouchableOpacity>
              ) : null}
            </View>
            <Text style={styles.addressText} numberOfLines={2}>
              {[
                selectedAddress.addressLine,
                selectedAddress.landmark,
                selectedAddress.city,
                selectedAddress.pincode,
              ]
                .filter(Boolean)
                .join(", ")}
            </Text>
          </View>
        ) : (
          <View style={styles.emptyAddressCard}>
            <MapPin size={20} color="#16863A" />
            <Text style={styles.emptyAddressText}>Add work address</Text>
            <TouchableOpacity style={styles.addAddressButton} onPress={() => router.push("/user/manage-addresses")}>
              <Text style={styles.addAddressButtonText}>Add</Text>
            </TouchableOpacity>
          </View>
        )}

        <View style={styles.summaryCard}>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Service</Text>
            <Text style={styles.summaryValue} numberOfLines={1}>{draft.skillName || "-"}</Text>
          </View>
          <View style={styles.separator} />
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Workers</Text>
            <Text style={styles.summaryValue}>{workerCount} · {ratingText}</Text>
          </View>
          {draft.assignmentMode === "CUSTOMER_SELECT" ? (
            <>
              <View style={styles.separator} />
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Selected</Text>
                <Text style={styles.summaryValue} numberOfLines={1}>{selectedWorkerNames || "-"}</Text>
              </View>
            </>
          ) : null}
          <View style={styles.separator} />
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Nakas</Text>
            <Text style={styles.summaryValue}>{selectedNakaCount} nearby</Text>
          </View>
          <View style={styles.separator} />
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Location</Text>
            <Text style={styles.summaryValue} numberOfLines={2}>{draft.workAddress || "Confirmed"}</Text>
          </View>
        </View>

        <View style={styles.amountCard}>
          <View>
            <Text style={styles.amountLabel}>Total</Text>
            <Text style={styles.amountHelper}>₹{unitPrice} × {workerCount}</Text>
          </View>
          <Text style={styles.amountValue}>₹{totalAmount}</Text>
        </View>

        <TouchableOpacity
          activeOpacity={0.85}
          disabled={isPaying || !selectedAddress || unitPrice <= 0}
          style={[styles.paymentButton, (!selectedAddress || unitPrice <= 0 || isPaying) && styles.paymentButtonDisabled]}
          onPress={handleProceedToPayment}
        >
          {isPaying ? (
            <ActivityIndicator size="small" color="#FFFFFF" />
          ) : (
            <Text style={styles.paymentButtonText}>Proceed to Payment</Text>
          )}
        </TouchableOpacity>
      </View>

      <Modal visible={showAddressModal} transparent animationType="fade" onRequestClose={() => setShowAddressModal(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Select Address</Text>
              <TouchableOpacity onPress={() => setShowAddressModal(false)}>
                <X size={24} color="#111827" />
              </TouchableOpacity>
            </View>

            {visibleAddresses.map((address: any) => {
              const isSelected = Number(selectedAddress?.id) === Number(address.id);
              return (
                <TouchableOpacity
                  key={address.id}
                  style={[styles.modalAddressItem, isSelected && styles.modalAddressItemActive]}
                  onPress={() => handleSelectAddress(address)}
                >
                  <View style={styles.modalAddressCopy}>
                    <Text style={[styles.modalAddressTitle, isSelected && styles.modalAddressTitleActive]}>
                      {address.title || "Saved Address"}
                    </Text>
                    <Text style={styles.modalAddressText} numberOfLines={2}>
                      {[address.addressLine, address.city, address.pincode].filter(Boolean).join(", ")}
                    </Text>
                  </View>
                  <View style={[styles.modalCheck, isSelected && styles.modalCheckActive]}>
                    {isSelected ? <Check size={15} color="#FFFFFF" strokeWidth={3} /> : null}
                  </View>
                </TouchableOpacity>
              );
            })}

            <TouchableOpacity
              style={styles.manageAddressButton}
              onPress={() => {
                setShowAddressModal(false);
                router.push("/user/manage-addresses");
              }}
            >
              <Text style={styles.manageAddressButtonText}>Manage Addresses</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#FFFFFF" },
  loaderContainer: { flex: 1, backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center" },
  content: { flex: 1, paddingHorizontal: 16, paddingTop: 12, paddingBottom: 10 },
  addressCard: { minHeight: 82, borderWidth: 1, borderColor: "#E5E7EB", borderRadius: 14, padding: 12, backgroundColor: "#FFFFFF" },
  cardTopRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  addressTitleRow: { flexDirection: "row", alignItems: "center", flex: 1 },
  cardTitle: { color: "#111827", fontSize: 14, fontWeight: "900", marginLeft: 7 },
  changeText: { color: "#16863A", fontSize: 12, fontWeight: "900" },
  addressText: { color: "#4B5563", fontSize: 12, lineHeight: 17, marginTop: 8 },
  emptyAddressCard: { height: 66, borderWidth: 1, borderColor: "#E5E7EB", borderRadius: 14, flexDirection: "row", alignItems: "center", paddingHorizontal: 12 },
  emptyAddressText: { flex: 1, color: "#111827", fontSize: 13, fontWeight: "800", marginLeft: 8 },
  addAddressButton: { backgroundColor: "#16863A", borderRadius: 10, paddingHorizontal: 14, paddingVertical: 8 },
  addAddressButtonText: { color: "#FFFFFF", fontSize: 12, fontWeight: "900" },
  summaryCard: { marginTop: 10, borderWidth: 1, borderColor: "#E5E7EB", borderRadius: 14, paddingHorizontal: 12, backgroundColor: "#FFFFFF" },
  summaryRow: { minHeight: 45, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  summaryLabel: { color: "#6B7280", fontSize: 12, fontWeight: "700" },
  summaryValue: { flex: 1, marginLeft: 16, textAlign: "right", color: "#111827", fontSize: 12, lineHeight: 16, fontWeight: "800" },
  separator: { height: 1, backgroundColor: "#EEF0F2" },
  amountCard: { height: 76, marginTop: 10, borderRadius: 14, paddingHorizontal: 14, flexDirection: "row", alignItems: "center", justifyContent: "space-between", backgroundColor: "#F0F9F2", borderWidth: 1, borderColor: "#CFE8D7" },
  amountLabel: { color: "#111827", fontSize: 13, fontWeight: "900" },
  amountHelper: { color: "#6B7280", fontSize: 11, marginTop: 3 },
  amountValue: { color: "#16863A", fontSize: 27, fontWeight: "900" },
  paymentButton: { height: 50, borderRadius: 13, backgroundColor: "#16863A", alignItems: "center", justifyContent: "center", marginTop: "auto" },
  paymentButtonDisabled: { opacity: 0.5 },
  paymentButtonText: { color: "#FFFFFF", fontSize: 16, fontWeight: "900" },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.42)", justifyContent: "center", paddingHorizontal: 18 },
  modalCard: { backgroundColor: "#FFFFFF", borderRadius: 22, padding: 16, maxHeight: "78%" },
  modalHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 12 },
  modalTitle: { color: "#111827", fontSize: 18, fontWeight: "900" },
  modalAddressItem: { minHeight: 68, borderWidth: 1, borderColor: "#E5E7EB", borderRadius: 13, paddingHorizontal: 12, paddingVertical: 9, marginBottom: 8, flexDirection: "row", alignItems: "center" },
  modalAddressItemActive: { borderColor: "#16863A", borderWidth: 2, backgroundColor: "#F0F9F2" },
  modalAddressCopy: { flex: 1, paddingRight: 10 },
  modalAddressTitle: { color: "#111827", fontSize: 13, fontWeight: "900" },
  modalAddressTitleActive: { color: "#16863A" },
  modalAddressText: { color: "#6B7280", fontSize: 11, lineHeight: 15, marginTop: 3 },
  modalCheck: { width: 27, height: 27, borderRadius: 14, borderWidth: 2, borderColor: "#D1D5DB", alignItems: "center", justifyContent: "center" },
  modalCheckActive: { borderColor: "#16863A", backgroundColor: "#16863A" },
  manageAddressButton: { height: 46, marginTop: 4, borderRadius: 12, backgroundColor: "#F0F9F2", alignItems: "center", justifyContent: "center" },
  manageAddressButtonText: { color: "#16863A", fontSize: 14, fontWeight: "900" },
});
