import AsyncStorage from "@react-native-async-storage/async-storage";
import axios from "axios";
import * as Location from "expo-location";
import { router, Stack } from "expo-router";
import {
  LocateFixed,
  MapPin,
  Navigation,
  X,
} from "lucide-react-native";
import React, { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Modal,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  useWindowDimensions,
  View,
} from "react-native";
import MapView, {
  Circle,
  Marker,
  type LatLng,
  type Region,
} from "react-native-maps";
import BookingStepHeader from "../../components/booking-step-header";
import { API_URL } from "../../constants/api";

const DEFAULT_RADIUS_METERS = 5000;

type NakaOption = {
  id: number;
  name: string;
  pincode?: string | null;
  landmark?: string | null;
  latitude: number;
  longitude: number;
  distanceKm: number;
  distanceMeters?: number;
  city?: {
    id: number;
    name: string;
  } | null;
};

type BookingDraft = {
  skillId?: number;
  skillName?: string;
  minRating?: number;
  workerCount?: number;
  assignmentMode?: "AUTO" | "CUSTOMER_SELECT";
  workLatitude?: number;
  workLongitude?: number;
  workAddress?: string;
  serviceRadiusKm?: number;
  serviceRadiusMeters?: number;
  selectedNakas?: NakaOption[];
  nakaIds?: number[];
  selectedWorkerIds?: number[];
  selectedWorkers?: unknown[];
};

type MapSettings = {
  showMap: boolean;
  radiusMeters: number;
  apiKey?: string | null;
};

const DEFAULT_REGION: Region = {
  latitude: 19.076,
  longitude: 72.8777,
  latitudeDelta: 0.13,
  longitudeDelta: 0.13,
};

const regionFor = (coordinate: LatLng): Region => ({
  ...coordinate,
  latitudeDelta: 0.115,
  longitudeDelta: 0.115,
});

const formatRadius = (radiusMeters: number) =>
  radiusMeters >= 1000
    ? `${Number((radiusMeters / 1000).toFixed(1))} km`
    : `${radiusMeters} m`;

export default function BookWorkerStep2() {
  const { height } = useWindowDimensions();
  const mapRef = useRef<MapView | null>(null);
  const nearbyRequestRef = useRef(0);
  const addressRequestRef = useRef(0);

  const [draft, setDraft] = useState<BookingDraft>({});
  const [region, setRegion] = useState<Region>(DEFAULT_REGION);
  const [workLocation, setWorkLocation] = useState<LatLng | null>(null);
  const [workAddress, setWorkAddress] = useState("");
  const [nearbyNakas, setNearbyNakas] = useState<NakaOption[]>([]);
  const [systemNakas, setSystemNakas] = useState<NakaOption[]>([]);
  const [mapSettings, setMapSettings] = useState<MapSettings>({
    showMap: false,
    radiusMeters: DEFAULT_RADIUS_METERS,
    apiKey: null,
  });
  const [isLocating, setIsLocating] = useState(false);
  const [isLoadingNakas, setIsLoadingNakas] = useState(false);
  const [isContinuing, setIsContinuing] = useState(false);
  const [locationPermissionDenied, setLocationPermissionDenied] =
    useState(false);
  const [showNakaModal, setShowNakaModal] = useState(false);

  const mapHeight = Math.max(178, Math.min(235, height * 0.27));

  useEffect(() => {
    let isMounted = true;

    const initialise = async () => {
      try {
        try {
          const optionResponse = await axios.get(
            `${API_URL}/user/booking-options`,
          );
          const optionMapSettings = optionResponse.data?.mapSettings;

          if (isMounted) {
            setMapSettings({
              showMap: Boolean(optionMapSettings?.showMap),
              radiusMeters:
                Number(optionMapSettings?.radiusMeters) ||
                DEFAULT_RADIUS_METERS,
              apiKey: optionMapSettings?.apiKey || null,
            });
          }
        } catch (settingError) {
          console.log("Booking map setting load error:", settingError);
        }

        const savedDraft = await AsyncStorage.getItem("newBookingDraft");
        const parsedDraft: BookingDraft = savedDraft
          ? JSON.parse(savedDraft)
          : {};

        if (!isMounted) return;
        setDraft(parsedDraft);

        const latitude = Number(parsedDraft.workLatitude);
        const longitude = Number(parsedDraft.workLongitude);

        if (
          Number.isFinite(latitude) &&
          Number.isFinite(longitude) &&
          latitude >= -90 &&
          latitude <= 90 &&
          longitude >= -180 &&
          longitude <= 180
        ) {
          await applyWorkLocation(
            { latitude, longitude },
            parsedDraft.workAddress || "",
            false,
          );
        } else {
          await fetchCurrentLocation(false);
        }
      } catch (error) {
        console.log("Work location initialise error:", error);
      }
    };

    initialise();

    return () => {
      isMounted = false;
      nearbyRequestRef.current += 1;
    };
    // Initialisation must run only once; callbacks use state setters safely.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadNearbyNakas = async (coordinate: LatLng) => {
    const requestId = nearbyRequestRef.current + 1;
    nearbyRequestRef.current = requestId;

    try {
      setIsLoadingNakas(true);
      setNearbyNakas([]);
      setSystemNakas([]);

      const response = await axios.post(`${API_URL}/user/nakas/nearby`, {
        workLatitude: coordinate.latitude,
        workLongitude: coordinate.longitude,
      });

      if (requestId !== nearbyRequestRef.current) return;

      setNearbyNakas(response.data.nearbyNakas || []);
      setSystemNakas(response.data.selectedNakas || []);
      setMapSettings({
        showMap: Boolean(response.data.mapSettings?.showMap),
        radiusMeters:
          Number(response.data.mapSettings?.radiusMeters) ||
          Number(response.data.radiusMeters) ||
          DEFAULT_RADIUS_METERS,
        apiKey: response.data.mapSettings?.apiKey || null,
      });
    } catch (error: any) {
      if (requestId !== nearbyRequestRef.current) return;

      console.log("Nearby Nakas error:", error?.response?.data || error);
      setNearbyNakas([]);
      setSystemNakas([]);

      Alert.alert(
        "Nearby Nakas",
        error?.response?.data?.message ||
          "Nearby Nakas load nahi ho paye. Please try again.",
      );
    } finally {
      if (requestId === nearbyRequestRef.current) {
        setIsLoadingNakas(false);
      }
    }
  };

  const resolveAddress = async (coordinate: LatLng) => {
    try {
      const addressList = await Location.reverseGeocodeAsync(coordinate);
      const address = addressList[0];

      if (!address) return "";

      return [
        address.name,
        address.street,
        address.district,
        address.city,
        address.region,
        address.postalCode,
      ]
        .filter(Boolean)
        .filter((value, index, values) => values.indexOf(value) === index)
        .join(", ");
    } catch (error) {
      console.log("Reverse geocode error:", error);
      return "";
    }
  };

  const applyWorkLocation = async (
    coordinate: LatLng,
    existingAddress = "",
    animate = true,
  ) => {
    const nextRegion = regionFor(coordinate);
    const addressRequestId = addressRequestRef.current + 1;
    addressRequestRef.current = addressRequestId;
    setWorkLocation(coordinate);
    setRegion(nextRegion);

    if (animate) {
      mapRef.current?.animateToRegion(nextRegion, 450);
    }

    setWorkAddress(
      existingAddress ||
        `${coordinate.latitude.toFixed(6)}, ${coordinate.longitude.toFixed(6)}`,
    );

    void loadNearbyNakas(coordinate);

    if (!existingAddress) {
      const resolvedAddress = await resolveAddress(coordinate);
      if (
        resolvedAddress &&
        addressRequestId === addressRequestRef.current
      ) {
        setWorkAddress(resolvedAddress);
      }
    }
  };

  const fetchCurrentLocation = async (showAlert: boolean) => {
    try {
      setIsLocating(true);
      const permission = await Location.requestForegroundPermissionsAsync();

      if (permission.status !== "granted") {
        setLocationPermissionDenied(true);

        if (showAlert) {
          Alert.alert(
            "Location Permission Required",
            mapSettings.showMap
              ? "Current location use karne ke liye app settings me location permission allow karein. Aap map par tap karke bhi work location set kar sakte hain."
              : "Work location use karne ke liye app settings me location permission allow karein.",
          );
        }
        return;
      }

      setLocationPermissionDenied(false);
      const position = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.High,
      });

      await applyWorkLocation({
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
      });
    } catch (error) {
      console.log("Current location error:", error);

      if (showAlert) {
        Alert.alert(
          "Location Error",
          mapSettings.showMap
            ? "Current location fetch nahi ho payi. GPS on karke dobara try karein, ya map par location set karein."
            : "Current location fetch nahi ho payi. GPS on karke dobara try karein.",
        );
      }
    } finally {
      setIsLocating(false);
    }
  };

  const handleContinue = async () => {
    if (!workLocation) {
      Alert.alert("Work Location", "Please work location confirm karein.");
      return;
    }

    if (systemNakas.length === 0) {
      Alert.alert(
        "Service Unavailable",
        `Is location ke ${formatRadius(mapSettings.radiusMeters)} radius me koi verified Naka nahi mila. Please work location change karein.`,
      );
      return;
    }

    try {
      setIsContinuing(true);
      const optionResponse = await axios.get(`${API_URL}/user/booking-options`);
      const assignmentMode: "AUTO" | "CUSTOMER_SELECT" =
        optionResponse.data.assignmentMode === "CUSTOMER_SELECT"
          ? "CUSTOMER_SELECT"
          : "AUTO";

      const nextDraft: BookingDraft = {
        ...draft,
        assignmentMode,
        workLatitude: workLocation.latitude,
        workLongitude: workLocation.longitude,
        workAddress,
        serviceRadiusKm: mapSettings.radiusMeters / 1000,
        serviceRadiusMeters: mapSettings.radiusMeters,
        selectedNakas: systemNakas,
        nakaIds: systemNakas.map((naka) => naka.id),
        selectedWorkerIds: [],
        selectedWorkers: [],
      };

      await AsyncStorage.setItem(
        "newBookingDraft",
        JSON.stringify(nextDraft),
      );

      router.push(
        assignmentMode === "CUSTOMER_SELECT"
          ? "/user/book-worker-select-workers"
          : "/user/book-worker-step3",
      );
    } catch (error: any) {
      console.log("Work location continue error:", error?.response?.data || error);
      Alert.alert(
        "Unable to Continue",
        error?.response?.data?.message || "Please try again.",
      );
    } finally {
      setIsContinuing(false);
    }
  };

  const previewNakas = nearbyNakas.slice(0, 3);

  return (
    <SafeAreaView style={styles.safeArea}>
      <Stack.Screen options={{ headerShown: false }} />
      <BookingStepHeader step={2} />

      <View style={styles.content}>
        {mapSettings.showMap ? (
          <View style={[styles.mapCard, { height: mapHeight }]}>
            <MapView
              ref={mapRef}
              style={StyleSheet.absoluteFill}
              region={region}
              showsCompass
              showsUserLocation={!locationPermissionDenied}
              showsMyLocationButton={false}
              onPress={(event) => void applyWorkLocation(event.nativeEvent.coordinate)}
            >
              {workLocation ? (
                <>
                  <Circle
                    center={workLocation}
                    radius={mapSettings.radiusMeters}
                    fillColor="rgba(5, 150, 105, 0.10)"
                    strokeColor="rgba(5, 150, 105, 0.7)"
                    strokeWidth={2}
                  />
                  <Marker
                    coordinate={workLocation}
                    draggable
                    pinColor="#059669"
                    title="Work location"
                    onDragEnd={(event) =>
                      void applyWorkLocation(event.nativeEvent.coordinate, "", false)
                    }
                  />
                </>
              ) : null}

              {nearbyNakas.map((naka) => (
                <Marker
                  key={naka.id}
                  stopPropagation
                  coordinate={{
                    latitude: Number(naka.latitude),
                    longitude: Number(naka.longitude),
                  }}
                  pinColor="#F59E0B"
                  title={naka.name}
                />
              ))}
            </MapView>

            <View style={styles.mapHint}>
              <Navigation size={13} color="#065F46" />
              <Text style={styles.mapHintText}>Tap or drag pin</Text>
            </View>

            {isLoadingNakas ? (
              <View style={styles.mapLoader}>
                <ActivityIndicator color="#059669" size="small" />
              </View>
            ) : null}
          </View>
        ) : (
          <View style={styles.locationPreview}>
            <MapPin size={24} color="#059669" />
            <Text style={styles.locationPreviewText} numberOfLines={2}>
              {workLocation ? workAddress : "Select work location"}
            </Text>
          </View>
        )}

        <TouchableOpacity
          style={styles.locationButton}
          activeOpacity={0.85}
          disabled={isLocating}
          onPress={() => void fetchCurrentLocation(true)}
        >
          {isLocating ? (
            <ActivityIndicator size="small" color="#FFFFFF" />
          ) : (
            <LocateFixed size={18} color="#FFFFFF" />
          )}
          <Text style={styles.locationButtonText}>
            {isLocating ? "Locating…" : "Use Current Location"}
          </Text>
        </TouchableOpacity>

        <View style={styles.confirmedCard}>
          <MapPin size={18} color="#059669" />
          <View style={styles.confirmedCopy}>
            <Text style={styles.confirmedLabel}>Work Location</Text>
            <Text style={styles.confirmedValue} numberOfLines={2}>
              {workLocation ? workAddress : "Not selected"}
            </Text>
          </View>
        </View>

        <View style={styles.nakaSection}>
          <View style={styles.nakaHeader}>
            <Text style={styles.nakaTitle}>Nearby Nakas</Text>
            <Text style={styles.nakaCount}>
              {isLoadingNakas ? "…" : `${nearbyNakas.length}`}
            </Text>
          </View>

          <View style={styles.nakaChips}>
            {previewNakas.map((naka) => (
              <View key={naka.id} style={styles.nakaChip}>
                <Text style={styles.nakaChipText} numberOfLines={1}>{naka.name}</Text>
              </View>
            ))}
            {nearbyNakas.length > 3 ? (
              <TouchableOpacity style={styles.moreChip} onPress={() => setShowNakaModal(true)}>
                <Text style={styles.moreChipText}>+{nearbyNakas.length - 3} More</Text>
              </TouchableOpacity>
            ) : null}
          </View>
        </View>

        <TouchableOpacity
          style={[
            styles.continueButton,
            (!workLocation || systemNakas.length === 0 || isLoadingNakas || isContinuing) &&
              styles.continueButtonDisabled,
          ]}
          activeOpacity={0.86}
          disabled={!workLocation || systemNakas.length === 0 || isLoadingNakas || isContinuing}
          onPress={() => void handleContinue()}
        >
          {isContinuing ? (
            <ActivityIndicator color="#FFFFFF" />
          ) : (
            <Text style={styles.continueButtonText}>Continue</Text>
          )}
        </TouchableOpacity>
      </View>

      <Modal visible={showNakaModal} transparent animationType="slide" onRequestClose={() => setShowNakaModal(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Nearby Nakas</Text>
              <TouchableOpacity onPress={() => setShowNakaModal(false)}>
                <X size={23} color="#111827" />
              </TouchableOpacity>
            </View>
            <FlatList
              data={nearbyNakas}
              keyExtractor={(item) => String(item.id)}
              showsVerticalScrollIndicator={false}
              renderItem={({ item }) => (
                <View style={styles.modalNakaRow}>
                  <View style={styles.modalNakaCopy}>
                    <Text style={styles.modalNakaName}>{item.name}</Text>
                    <Text style={styles.modalNakaMeta} numberOfLines={1}>
                      {[item.city?.name, item.pincode].filter(Boolean).join(" • ")}
                    </Text>
                  </View>
                  <Text style={styles.modalNakaDistance}>
                    {item.distanceMeters != null && item.distanceMeters < 1000
                      ? `${item.distanceMeters} m`
                      : `${item.distanceKm.toFixed(1)} km`}
                  </Text>
                </View>
              )}
            />
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: "#FFFFFF" },
  content: { flex: 1, paddingHorizontal: 16, paddingTop: 12, paddingBottom: 10 },
  mapCard: { overflow: "hidden", borderRadius: 18, backgroundColor: "#E2E8F0", borderWidth: 1, borderColor: "#DDE7E1" },
  mapHint: { position: "absolute", top: 10, left: 10, flexDirection: "row", alignItems: "center", gap: 5, borderRadius: 16, paddingHorizontal: 9, paddingVertical: 6, backgroundColor: "rgba(255,255,255,0.94)" },
  mapHintText: { color: "#065F46", fontSize: 10, fontWeight: "800" },
  mapLoader: { position: "absolute", right: 10, bottom: 10, width: 34, height: 34, borderRadius: 17, alignItems: "center", justifyContent: "center", backgroundColor: "rgba(255,255,255,0.95)" },
  locationPreview: { height: 88, borderWidth: 1, borderColor: "#DDE7E1", borderRadius: 18, backgroundColor: "#F8FAF9", flexDirection: "row", alignItems: "center", paddingHorizontal: 16 },
  locationPreviewText: { flex: 1, marginLeft: 10, color: "#111827", fontSize: 13, lineHeight: 18, fontWeight: "700" },
  locationButton: { height: 48, marginTop: 10, borderRadius: 13, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, backgroundColor: "#059669" },
  locationButtonText: { color: "#FFFFFF", fontSize: 14, fontWeight: "900" },
  confirmedCard: { minHeight: 64, marginTop: 10, borderRadius: 14, paddingHorizontal: 13, paddingVertical: 10, flexDirection: "row", alignItems: "center", backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#E5E7EB" },
  confirmedCopy: { flex: 1, marginLeft: 9 },
  confirmedLabel: { color: "#059669", fontSize: 10, fontWeight: "900" },
  confirmedValue: { color: "#111827", fontSize: 12, lineHeight: 16, fontWeight: "700", marginTop: 2 },
  nakaSection: { marginTop: 10, borderWidth: 1, borderColor: "#E5E7EB", borderRadius: 14, padding: 11, backgroundColor: "#FFFFFF" },
  nakaHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 8 },
  nakaTitle: { color: "#111827", fontSize: 13, fontWeight: "900" },
  nakaCount: { color: "#059669", fontSize: 12, fontWeight: "900" },
  nakaChips: { flexDirection: "row", flexWrap: "wrap", gap: 6 },
  nakaChip: { maxWidth: "46%", backgroundColor: "#F0FDF4", borderRadius: 10, paddingHorizontal: 9, paddingVertical: 6 },
  nakaChipText: { color: "#047857", fontSize: 10, fontWeight: "800" },
  moreChip: { backgroundColor: "#ECFDF5", borderRadius: 10, paddingHorizontal: 9, paddingVertical: 6 },
  moreChipText: { color: "#16863A", fontSize: 10, fontWeight: "900" },
  continueButton: { height: 50, borderRadius: 13, marginTop: "auto", alignItems: "center", justifyContent: "center", backgroundColor: "#16863A" },
  continueButtonDisabled: { backgroundColor: "#9CA3AF" },
  continueButtonText: { color: "#FFFFFF", fontSize: 16, fontWeight: "900" },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.42)", justifyContent: "flex-end" },
  modalCard: { height: "68%", backgroundColor: "#FFFFFF", borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingHorizontal: 16, paddingTop: 16, paddingBottom: 14 },
  modalHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 10 },
  modalTitle: { color: "#111827", fontSize: 18, fontWeight: "900" },
  modalNakaRow: { minHeight: 58, borderBottomWidth: 1, borderBottomColor: "#EEF2F0", flexDirection: "row", alignItems: "center" },
  modalNakaCopy: { flex: 1, paddingRight: 10 },
  modalNakaName: { color: "#111827", fontSize: 13, fontWeight: "800" },
  modalNakaMeta: { color: "#6B7280", fontSize: 11, marginTop: 2 },
  modalNakaDistance: { color: "#059669", fontSize: 11, fontWeight: "800" },
});
