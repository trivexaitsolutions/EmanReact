import AsyncStorage from "@react-native-async-storage/async-storage";
import axios from "axios";
import { Stack, router } from "expo-router";
import {
  BriefcaseBusiness,
  Grid2X2,
  Minus,
  Plus,
  Search,
  Star,
  X,
} from "lucide-react-native";
import React, { useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Image,
  Modal,
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import BookingStepHeader from "../../components/booking-step-header";
import { API_URL } from "../../constants/api";

const SERVER_URL = API_URL.replace(/\/api\/?$/, "");

const getSkillImageUri = (imageUrl?: string | null) => {
  if (!imageUrl) return null;
  if (/^https?:\/\//i.test(imageUrl)) return imageUrl;
  return `${SERVER_URL}${imageUrl.startsWith("/") ? "" : "/"}${imageUrl}`;
};

export default function BookWorkerStep1() {
  const [skills, setSkills] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedSkill, setSelectedSkill] = useState<number | null>(null);
  const [selectedSkillName, setSelectedSkillName] = useState("");
  const [minRating, setMinRating] = useState(0);
  const [workerCount, setWorkerCount] = useState(1);
  const [showSkillModal, setShowSkillModal] = useState(false);
  const [skillSearch, setSkillSearch] = useState("");
  const [modalSelectedSkill, setModalSelectedSkill] = useState<number | null>(null);

  useEffect(() => {
    void loadSkills();
    void loadSavedDraft();
  }, []);

  const filteredSkills = useMemo(() => {
    const query = skillSearch.trim().toLowerCase();
    if (!query) return skills;
    return skills.filter((skill: any) =>
      String(skill.name || "").toLowerCase().includes(query),
    );
  }, [skillSearch, skills]);

  const loadSkills = async () => {
    try {
      const response = await axios.get(`${API_URL}/user/booking-options`);
      if (response.data.success) setSkills(response.data.skills || []);
    } catch (error) {
      console.log("Skill load error:", error);
      Alert.alert("Error", "Skills load nahi ho paye. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const loadSavedDraft = async () => {
    try {
      const savedDraft = await AsyncStorage.getItem("newBookingDraft");
      if (!savedDraft) return;
      const draft = JSON.parse(savedDraft);
      if (draft.skillId) setSelectedSkill(Number(draft.skillId));
      if (draft.skillName) setSelectedSkillName(draft.skillName);
      if (draft.minRating !== undefined) setMinRating(Number(draft.minRating));
      if (draft.workerCount) setWorkerCount(Number(draft.workerCount));
    } catch (error) {
      console.log("Draft load error:", error);
    }
  };

  const handleSkillSelect = (skill: any) => {
    setSelectedSkill(Number(skill.id));
    setSelectedSkillName(skill.name);
  };

  const openSkillModal = () => {
    setSkillSearch("");
    setModalSelectedSkill(selectedSkill);
    setShowSkillModal(true);
  };

  const submitModalSkill = () => {
    const selected = skills.find(
      (skill: any) => Number(skill.id) === Number(modalSelectedSkill),
    );
    if (!selected) {
      Alert.alert("Select Skill", "Please select a service.");
      return;
    }
    handleSkillSelect(selected);
    setShowSkillModal(false);
  };

  const handleRatingSelect = (star: number) => {
    setMinRating((current) => (current === star ? 0 : star));
  };

  const handleNext = async () => {
    if (!selectedSkill) {
      Alert.alert("Select Skill", "Please select the type of worker you need.");
      return;
    }

    try {
      const oldDraft = await AsyncStorage.getItem("newBookingDraft");
      const existingDraft = oldDraft ? JSON.parse(oldDraft) : {};
      await AsyncStorage.setItem(
        "newBookingDraft",
        JSON.stringify({
          ...existingDraft,
          skillId: selectedSkill,
          skillName: selectedSkillName,
          minRating,
          workerCount,
        }),
      );
      router.push("/user/book-worker-step2");
    } catch (error) {
      console.log("Draft save error:", error);
      Alert.alert("Error", "Booking details save nahi ho payi.");
    }
  };

  const primarySkills = skills.slice(0, 3);
  const selectedOutsidePrimary =
    selectedSkill &&
    !primarySkills.some((skill: any) => Number(skill.id) === Number(selectedSkill));

  if (isLoading) {
    return (
      <SafeAreaView style={styles.loaderContainer}>
        <Stack.Screen options={{ headerShown: false }} />
        <ActivityIndicator size="large" color="#16863A" />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen options={{ headerShown: false }} />
      <BookingStepHeader step={1} />

      <View style={styles.content}>
        <Text style={styles.sectionTitle}>Service</Text>
        <View style={styles.skillGrid}>
          {primarySkills.map((skill: any) => {
            const isSelected = Number(selectedSkill) === Number(skill.id);
            const imageUri = getSkillImageUri(skill.imageUrl);
            return (
              <TouchableOpacity
                key={skill.id}
                activeOpacity={0.82}
                style={[styles.skillCard, isSelected && styles.skillCardActive]}
                onPress={() => handleSkillSelect(skill)}
              >
                <View style={styles.skillImageWrap}>
                  {imageUri ? (
                    <Image source={{ uri: imageUri }} style={styles.skillImage} resizeMode="cover" />
                  ) : (
                    <BriefcaseBusiness size={23} color={isSelected ? "#16863A" : "#6B7280"} />
                  )}
                </View>
                <Text numberOfLines={1} style={[styles.skillText, isSelected && styles.skillTextActive]}>
                  {skill.name}
                </Text>
              </TouchableOpacity>
            );
          })}

          {skills.length > 3 ? (
            <TouchableOpacity style={[styles.skillCard, styles.viewAllCard]} onPress={openSkillModal}>
              <View style={styles.skillImageWrap}>
                <Grid2X2 size={24} color="#16863A" />
              </View>
              <Text numberOfLines={1} style={styles.viewAllText}>
                {selectedOutsidePrimary ? selectedSkillName : "View All"}
              </Text>
            </TouchableOpacity>
          ) : null}
        </View>

        <View style={styles.rowHeader}>
          <Text style={styles.sectionTitle}>Rating</Text>
          <Text style={styles.helperText}>{minRating ? `${minRating}★+` : "Any"}</Text>
        </View>
        <View style={styles.ratingCard}>
          {[1, 2, 3, 4, 5].map((star) => {
            const active = star <= minRating;
            return (
              <TouchableOpacity key={star} style={styles.ratingItem} onPress={() => handleRatingSelect(star)}>
                <Star
                  size={27}
                  color={active ? "#16863A" : "#9CA3AF"}
                  fill={active ? "#16863A" : "transparent"}
                />
                <Text style={[styles.ratingNumber, active && styles.ratingNumberActive]}>{star}</Text>
              </TouchableOpacity>
            );
          })}
        </View>

        <View style={styles.rowHeader}>
          <Text style={styles.sectionTitle}>Workers</Text>
          <Text style={styles.helperText}>Max 10</Text>
        </View>
        <View style={styles.workerCountCard}>
          <Text style={styles.workerCountLabel}>Required</Text>
          <View style={styles.counter}>
            <TouchableOpacity style={styles.counterButton} onPress={() => setWorkerCount((value) => Math.max(1, value - 1))}>
              <Minus size={18} color="#111827" />
            </TouchableOpacity>
            <Text style={styles.counterValue}>{workerCount}</Text>
            <TouchableOpacity style={styles.counterButton} onPress={() => setWorkerCount((value) => Math.min(10, value + 1))}>
              <Plus size={18} color="#111827" />
            </TouchableOpacity>
          </View>
        </View>

        <TouchableOpacity activeOpacity={0.86} style={styles.nextButton} onPress={handleNext}>
          <Text style={styles.nextButtonText}>Next</Text>
        </TouchableOpacity>
      </View>

      <Modal visible={showSkillModal} transparent animationType="slide" onRequestClose={() => setShowSkillModal(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Select Service</Text>
              <TouchableOpacity onPress={() => setShowSkillModal(false)}>
                <X size={24} color="#111827" />
              </TouchableOpacity>
            </View>

            <View style={styles.searchBox}>
              <Search size={18} color="#6B7280" />
              <TextInput
                value={skillSearch}
                onChangeText={setSkillSearch}
                placeholder="Search service"
                placeholderTextColor="#9CA3AF"
                style={styles.searchInput}
              />
            </View>

            <FlatList
              data={filteredSkills}
              keyExtractor={(item: any) => String(item.id)}
              numColumns={2}
              columnWrapperStyle={styles.modalGridRow}
              contentContainerStyle={styles.modalList}
              showsVerticalScrollIndicator={false}
              renderItem={({ item }: any) => {
                const isSelected = Number(modalSelectedSkill) === Number(item.id);
                const imageUri = getSkillImageUri(item.imageUrl);
                return (
                  <TouchableOpacity
                    activeOpacity={0.82}
                    style={[styles.modalSkillCard, isSelected && styles.modalSkillCardActive]}
                    onPress={() => setModalSelectedSkill(Number(item.id))}
                  >
                    <View style={styles.modalSkillImageWrap}>
                      {imageUri ? (
                        <Image source={{ uri: imageUri }} style={styles.skillImage} resizeMode="cover" />
                      ) : (
                        <BriefcaseBusiness size={25} color={isSelected ? "#16863A" : "#6B7280"} />
                      )}
                    </View>
                    <Text numberOfLines={2} style={[styles.modalSkillText, isSelected && styles.skillTextActive]}>
                      {item.name}
                    </Text>
                  </TouchableOpacity>
                );
              }}
            />

            <TouchableOpacity style={styles.modalSubmitButton} onPress={submitModalSkill}>
              <Text style={styles.modalSubmitText}>Select</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#FFFFFF" },
  loaderContainer: { flex: 1, backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center" },
  content: { flex: 1, paddingHorizontal: 16, paddingTop: 12, paddingBottom: 10 },
  sectionTitle: { color: "#111827", fontSize: 15, fontWeight: "900", marginBottom: 8 },
  rowHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 12 },
  helperText: { color: "#16863A", fontSize: 12, fontWeight: "800", marginBottom: 8 },
  skillGrid: { flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between" },
  skillCard: {
    width: "48.5%",
    height: 94,
    borderWidth: 1,
    borderColor: "#E5E7EB",
    borderRadius: 14,
    backgroundColor: "#FFFFFF",
    marginBottom: 8,
    padding: 7,
  },
  skillCardActive: { borderColor: "#16863A", borderWidth: 2, backgroundColor: "#F0F9F2" },
  skillImageWrap: {
    height: 58,
    borderRadius: 10,
    overflow: "hidden",
    backgroundColor: "#F3F4F6",
    alignItems: "center",
    justifyContent: "center",
  },
  skillImage: { width: "100%", height: "100%" },
  skillText: { color: "#111827", fontSize: 12, fontWeight: "800", marginTop: 5, textAlign: "center" },
  skillTextActive: { color: "#16863A" },
  viewAllCard: { backgroundColor: "#F0F9F2", borderColor: "#C7E8D2" },
  viewAllText: { color: "#16863A", fontSize: 12, fontWeight: "900", marginTop: 5, textAlign: "center" },
  ratingCard: {
    height: 62,
    borderWidth: 1,
    borderColor: "#E5E7EB",
    borderRadius: 14,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-around",
    paddingHorizontal: 8,
  },
  ratingItem: { alignItems: "center", justifyContent: "center" },
  ratingNumber: { color: "#6B7280", fontSize: 11, fontWeight: "700", marginTop: 2 },
  ratingNumberActive: { color: "#16863A" },
  workerCountCard: {
    height: 58,
    borderWidth: 1,
    borderColor: "#E5E7EB",
    borderRadius: 14,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 14,
  },
  workerCountLabel: { color: "#111827", fontSize: 13, fontWeight: "800" },
  counter: { flexDirection: "row", alignItems: "center", borderWidth: 1, borderColor: "#E5E7EB", borderRadius: 10 },
  counterButton: { width: 38, height: 36, alignItems: "center", justifyContent: "center" },
  counterValue: { minWidth: 34, textAlign: "center", color: "#111827", fontSize: 17, fontWeight: "900" },
  nextButton: { height: 50, borderRadius: 13, backgroundColor: "#16863A", alignItems: "center", justifyContent: "center", marginTop: "auto" },
  nextButtonText: { color: "#FFFFFF", fontSize: 16, fontWeight: "900" },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.42)", justifyContent: "flex-end" },
  modalCard: {
    height: "82%",
    backgroundColor: "#FFFFFF",
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 14,
  },
  modalHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 12 },
  modalTitle: { color: "#111827", fontSize: 18, fontWeight: "900" },
  searchBox: {
    height: 46,
    borderRadius: 13,
    borderWidth: 1,
    borderColor: "#E5E7EB",
    backgroundColor: "#F9FAFB",
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    marginBottom: 12,
  },
  searchInput: { flex: 1, color: "#111827", fontSize: 14, marginLeft: 8, paddingVertical: 0 },
  modalList: { paddingBottom: 8 },
  modalGridRow: { justifyContent: "space-between" },
  modalSkillCard: {
    width: "48.5%",
    minHeight: 118,
    borderWidth: 1,
    borderColor: "#E5E7EB",
    borderRadius: 14,
    padding: 8,
    marginBottom: 10,
  },
  modalSkillCardActive: { borderColor: "#16863A", borderWidth: 2, backgroundColor: "#F0F9F2" },
  modalSkillImageWrap: {
    height: 74,
    borderRadius: 10,
    overflow: "hidden",
    backgroundColor: "#F3F4F6",
    alignItems: "center",
    justifyContent: "center",
  },
  modalSkillText: { color: "#111827", fontSize: 13, fontWeight: "800", textAlign: "center", marginTop: 6 },
  modalSubmitButton: { height: 50, borderRadius: 13, backgroundColor: "#16863A", alignItems: "center", justifyContent: "center", marginTop: 4 },
  modalSubmitText: { color: "#FFFFFF", fontSize: 16, fontWeight: "900" },
});
