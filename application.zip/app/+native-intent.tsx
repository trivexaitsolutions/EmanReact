type RedirectSystemPathOptions = {
  path: string;
  initial: boolean;
};

/**
 * Native payment apps can return to E-MAN with only the app scheme
 * (for example: emanreact:///). Expo Router otherwise treats that raw
 * callback as a page URL and opens the Unmatched Route screen.
 *
 * Rewrite only the empty E-MAN callback to the app root. Once the
 * Razorpay promise resumes, the existing booking code continues its
 * verification and redirects to /user/active-booking as before.
 */
export function redirectSystemPath({
  path,
}: RedirectSystemPathOptions): string {
  try {
    const incoming = String(path || "").trim();

    if (!incoming || incoming === "/") {
      return "/";
    }

    // Exact bare callbacks seen after returning from external payment apps.
    if (/^emanreact:\/\/*$/i.test(incoming)) {
      return "/";
    }

    // Keep all real Expo Router routes/deep links unchanged.
    const parsed = new URL(incoming, "emanreact://app");

    if (
      parsed.protocol.toLowerCase() === "emanreact:" &&
      !parsed.hostname &&
      (!parsed.pathname || parsed.pathname === "/")
    ) {
      return "/";
    }

    return path;
  } catch {
    // Never let a malformed third-party callback crash/open an unmatched page.
    return "/";
  }
}
